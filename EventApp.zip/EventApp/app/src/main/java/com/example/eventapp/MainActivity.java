package com.example.eventapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import cn.iwgang.countdownview.CountdownView;

public class MainActivity extends AppCompatActivity {
    private ImageButton donateBtn;
    private ImageButton navigateBtn;
    private static int SPLASH_TIME_OUT = 5000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setting up the countdown timer
        CountdownView myCountdownView = findViewById(R.id.countdownView);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String countDate = "27-09-2021 00:00:00";
        Date now = new Date();
        try{
            //String to date
            Date date = sdf.parse(countDate);
            long currentTime = now.getTime();
            long eventDate = date.getTime();
            long countdownEvent = eventDate - currentTime;

            myCountdownView.start(countdownEvent);
        }catch (ParseException e){
            e.printStackTrace();
        }

        donateBtn =(ImageButton) findViewById(R.id.donateButton);
        donateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDonatePage();
            }
        });

        navigateBtn = (ImageButton) findViewById(R.id.navigateBtn);
        navigateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNavigatePage();
            }
        });

    }

public void openDonatePage(){
    Intent intent = new Intent(this, DonationScreen.class);
    startActivity(intent);
}
public void openNavigatePage(){
        Intent intent = new Intent(this, Navigation.class);
        startActivity(intent);
}
}
