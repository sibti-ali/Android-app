package com.example.eventapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

public class DonationScreen extends AppCompatActivity {
    public ArrayList<Donator> donators;
    private ImageButton donateNowBtn;
    private EditText nameTF;
    private EditText emailTF;
    private EditText amountTF;
    private TextView donationsTV;
    String donation;
    boolean isEmailValid (CharSequence email){
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donation_screen);

        donators = new ArrayList<Donator>();
        Donator donator = new Donator("jimmy","hisemail",9);
        donators.add(donator);

        donateNowBtn = (ImageButton) findViewById(R.id.donateNowbtn);
        nameTF = (EditText) findViewById(R.id.nameTF);
        emailTF = (EditText) findViewById(R.id.emailTF);
        amountTF = (EditText) findViewById(R.id.amountTF);
        donationsTV = (TextView) findViewById(R.id.dontaionsTV);

        donateNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                donateNow();

            }
        });


    }
   public void donateNow(){
        if (nameTF.getText().length()  == 0 || emailTF.getText().length()  == 0 ||amountTF.getText().length()  == 0 ){
            Dialogue error = new Dialogue();
            error.show(getSupportFragmentManager(), "Error");
        }
        else {
            if (!isEmailValid(emailTF.getText().toString())) {
                Dialogue error = new Dialogue();
                error.show(getSupportFragmentManager(), "Error");
            }
            else{
                //this stores a list of all the donators in an arraylist that can be used for further implementations
                Donator newDonator = new Donator(nameTF.getText().toString(), emailTF.getText().toString(), Integer.parseInt(amountTF.getText().toString()));

                donators.add(newDonator);

                donation = String.valueOf(Integer.parseInt(amountTF.getText().toString()) + Integer.parseInt(donationsTV.getText().toString()));
                donationsTV.setText(donation);
                //clearing the fields
                nameTF.getText().clear();
                emailTF.getText().clear();
                amountTF.getText().clear();

                Intent intent = new Intent(this, PopUpWindow.class);
                startActivity(intent);
            }
        }
    }
}
