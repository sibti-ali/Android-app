package com.example.eventapp;

public class Donator {
    private String name;
    private String email;
    private Integer amount;

    public Donator(String name, String email, Integer amount) {
        this.name = name;
        this.email = email;
        this.amount = amount;
    }


}
